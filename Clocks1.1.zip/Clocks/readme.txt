# Clocks
Contributors: Toni Klätke  
Tags: clock, clocks, analog clock, digital clock, lcd clock
Requires at least: 4.0  
Tested up to: 5.6.1 
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html  

Become different Clocks with Shortcode for your WordPress System.

## Description
This plugin enables you to display the Clock.wtf Clocks on your site. The plugin can easy implement with a shortcode.

This Plugin is a 3rd Party Service. If you use the Clocks WordPress Plugin, you understand the riules and that you are Share your Visitor Data with the Plugin Provider.

The Provide from this WordPress Plugin is Clock.wtf.

Provider Statement: We don't track or analyse Data from our Visitors or from Third Party Visitors we get from our WordPress Plugins. More Details: https://clock.wtf/privacy

### Usage 
Shortcodes [analog-clock] & [lcd-clock] & [flip-clock]

## Screenshots

1. Homepage - You can see the Integrate Digital LCD Clock.

== Changelog ==

= 1.0 =
* Stabil Version from the Magic Plugin.

= 1.1 =
* New Clock: The Flip Clock with the Shortcode: [flip-clock]